# Databricks notebook source
# MAGIC %run ./backbone

# COMMAND ----------

"""Implement common functions used across the framework."""
from datetime import datetime
from pyspark.sql.functions import lit, col, udf, trim
from pyspark.sql import functions as F, DataFrame, Row
from pyspark.sql.types import StringType, IntegerType, TimestampType
from pyspark.sql.functions import when
from concurrent.futures import ThreadPoolExecutor
import logging as log
import json
import numbers
import traceback
import re


# COMMAND ----------

def execute(test,in_df=None):
  """Execute a test case.
  
  Args:
    test: spark.Row
  Returns: spark.DataFrame
  """
  start = datetime.now()
  try:
    test_result = process_row(test)  # Evaluate the test (i.e., call the test function); previous version process_row(test, in_df) did not work with job runs so in_df removed
    test_result = test_result.withColumn('start', lit(start))  # Log the test start time
    endTime = datetime.now()
    test_result = test_result.withColumn('end', lit(endTime))  # Log the test runtime (in seconds)
    test_result = test_result.withColumn('run_time', lit((endTime-start).total_seconds()))
    
    if test_result.rdd.isEmpty():
      result = 'no data'
      comments = job_url
      return report_template(test, result, job_id, comments, start)
    else:
      return test_result
    
  except Exception as e:
    print(f'ERROR: Test case {test["id"]} failed to execute\n{e}')
    result = 'error'
    comments = f'{e}\nurl:{job_url}'
    return report_template(test, result, job_id, comments, start)

# COMMAND ----------

 def get_limit(max_fail):
   '''
   Get the limit of how many failed attempts per test case to execute 
   Args:
     max_fail: str or int
   Returns: str or int
   '''
   try:
     if max_fail * 5 < 1000:
       return 1000
     else:
       return max_fail * 5
   except:
     return None

# COMMAND ----------

# def join_condition(src_db: str, src_table: str, target_db: str, target_table: str) -> str or None:
#   '''
#   Return the join condition for two tables.
#   Args:
#     src_db: str
#     src_table: str
#     src_column: str
#     target_db: str
#     target_table: str
#     target_column: str
#   Returns: str or None
#   '''
#   assert type(src_db) is str
#   assert type(src_table) is str
#   assert type(target_db) is str
#   assert type(target_table) is str
  
#   # Traverse the join_conditions dictionary in the backbone
#   # All join rules should be there
#   # Strucutre:
#   # {
#   #  "db_name_a": {
#   #      "table_name_a": {
#   #          "target_db_b": {
#   #              "table_name_b": "join_rule"
#   #          }
#   #      },
#   #      ...
#   #    }
#   # }
#   #
#   if src_db in Backbone.join_conditions:
#     if src_table in Backbone.join_conditions[src_db]:
#       if target_db in Backbone.join_conditions[src_db][src_table]:
#         if target_table in Backbone.join_conditions[src_db][src_table][target_db]:
#           return Backbone.join_conditions[src_db][src_table][target_db][target_table]
#   raise ValueError(f"Join rule for {src_db}.{src_table} to {target_db}.{target_table} not found")
  
  

# COMMAND ----------

class ErrorObj(object):
  
  def __init__(self,job_id,
               testcaseid,
               testdescription,
               result,sourcetable,
               sourcecolumn,
               sourcedatavalue,
               targettable,
               targetcolumn,
               targetdatavalue,
               comments,
               starttime,
               runduration,
               endtime):
    self.job_id = job_id,
    self.testcaseid =testcaseid
    self.testdescription=testdescription
    self.result=result
    self.sourcetable =sourcetable
    self.sourcecolumn =sourcecolumn
    self.sourcedatavalue =sourcedatavalue
    self.targettable =targettable
    self.targetcolumn =targetcolumn
    self.targetdatavalue =targetdatavalue
    self.comments =comments
    self.starttime =starttime
    self.runduration =runduration
    self.endtime =endtime
    
  def __repr__(self):
    return 'ErrorObj(testcaseid = {}, result = {}, sourcetable ={},sourcecolumn = {},targettable = {},targetcolumn={},targetdatavalue = {},testdescription = {},job_id = {})'.format(self.testcaseid,self.result,self.sourcetable,self.sourcecolumn,self.targettable,self.targetcolumn,self.targetdatavalue,self.testdescription,self.job_id)
    

# COMMAND ----------

def process_result(df, max_fail, nb_udf):
  '''Analyze the results of the test(s) and determine if a re-attempt is required.
  Tests execute in two phases:
    1. Sample of 1000 records (or whatever the max fail is)
    2. Test all records (possible millions)
    
  Args:
    df: spark.DataFrame
    max_fail: str or int
    nb_udf: spark.UserDefinedFunction
  Returns: spark.DataFrame
  '''
  if str(max_fail).lower() == 'all':
    # Return one passing test or all the failures to the report table
    if df.filter('result="fail"').count() == 0:
      return df.filter('result="pass"').limit(1)
    else:
      return df.filter('result="fail"')
  elif df.filter('result="fail"').count() >= max_fail:
    # Return the maximum number of failures to the test report table
    return df.filter('result="filter"').limit(max_fail)
  else:
    # Retest for all records
    df = query_data()
    df = df.withColumn(target_col, col(target_col).cast(StringType()))
    df = df.withColumn('result', nb_udf(src_col, target_col))
    
    if df.filter('result=="pass"').count() == df.count():
      return df.filter('result=="pass"').limit(1)
    else:
      return df.filter('result="fail"').limit(max_fail)    

# COMMAND ----------

def report_template(test, result, job_id, comments, start):
  '''Return a standard report dictionary with some placeholder data.'''
  report_data = [
    {
      "job_id": int(job_id),
      "test_case_id": str(test["id"]),
      "test_description": str(test["description"]),
      "source_table": test["src_table"],
      "source_column": test["src_column"],
      "target_table": test["target_table"],
      "target_column": test["target_column"],
      "root_key": None,
      "source_data_value": None,
      "target_data_value": None,
      "result": result,
      "comments": comments,
      "start": start,
      "end": datetime.now()
    }
  ]
  return spark.createDataFrame(report_data, schema=Backbone.report_schema)

# COMMAND ----------

def root_key_columns(db, table):
  '''Return the primary key (or composite key) fields use to uniquely identify records.
  
  Args:
    db: str
    table: str
  Returns: str or int
  '''
  query = f'SHOW COLUMNS FROM {db}.{table}'
  columns = spark.sql(query).collect()
  for c in columns:
    column_name = c[0]
    if column_name.lower().replace('_', '') in [x.replace('_', '') for x in Backbone.possible_root_keys]:
      return column_name
    else:
      raise ValueError('No root key columns identified in {db}.{table}')