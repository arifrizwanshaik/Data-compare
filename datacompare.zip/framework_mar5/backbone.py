# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType, FloatType, DoubleType
import json

# COMMAND ----------

class Backbone:
  """Basic configuration object to store shared variables across the framework"""
  # Databases
  src_db = "demo_source"  # Source system database
  target_db = "demo_target"  # Target system database
  help_db = "demo_test_auto"  # Test case database
  report_db = "demo_test_auto" # Reporting database
  
  # Table configurations
  report_table = "test_results"
  
  # List of tables to migrate via ETL
  tables_to_migrate = [
    "product",
    "customer",
    "account",
    "party",
    "transaction"
  ]
  
  # Root Key Values
  possible_root_keys = [
    "account_uuid",
    "customer_uuid",
    "party_uuid",
    "transaction_uuid",
    "product_uuid"
  ]
  
  # Schema join conditions
  join_conditions = {
    src_db: {
      "account": {
        target_db: {
          "account": f"JOIN {target_db}.account AS target ON source.account_uuid = target.account_uuid"
        }
      },
      "customer": {
        target_db: {
          "customer": f"JOIN {target_db}.customer AS target ON source.customer_uuid = target.customer_uuid"
        }
      },
      "party": {
        target_db: {
          "party": f"JOIN {target_db}.party AS target ON source.party_uuid = target.party_uuid"
        }
      },
      "product": {
        target_db: {
            "product": f"JOIN {target_db}.product AS target ON source.product_uuid = target.product_uuid",
        }
      },
      "transaction": {
        target_db: {
          "transaction": f"JOIN {target_db}.transaction AS target ON source.transaction_uuid = target.transaction_uuid"
        }
      }
    }
  }
  
  # Schemas
  test_case_schema = StructType(
    [
      StructField("id", IntegerType(), False),
      StructField("description", StringType(), True),
      StructField("src_table", StringType(), True),
      StructField("src_column", StringType(), True),
      StructField("target_table", StringType(), True),
      StructField("target_column", StringType(), True),
      StructField("test_function", StringType(), True),
      StructField("condition", StringType(), True),
    ]
  )
  report_schema = StructType(
    [
      StructField("job_id", StringType(), False),
      StructField("test_case_id", StringType(), False),
      StructField("test_description", StringType(), True),
      StructField("source_table", StringType(), True),
      StructField("source_column", StringType(), True),
      StructField("target_table", StringType(), True),
      StructField("target_column", StringType(), True),
      StructField("root_key", StringType(), True),
      StructField("source_data_value", StringType(), True),
      StructField("target_data_value", StringType(), True),
      StructField("result", StringType(), True),
      StructField("comments", StringType(), True),
      StructField("sql_query", StringType(), True),
      StructField("start", TimestampType(), True),
      StructField("end", TimestampType(), True),
      StructField("run_time", StringType(), True)
    ]
  )
  
  account_schema = StructType(
    [
      StructField("account_uuid", StringType(), False),
      StructField("product_uuid", StringType(), False),
      StructField("balance", DoubleType(), False),
      StructField("status", StringType(), True),
      StructField("date_opened", TimestampType(), False),
      StructField("date_closed", TimestampType(), True),
    ]
  )
  
  customer_schema = StructType(
    [
      StructField("customer_uuid", StringType(), False),
      StructField("prefix", StringType(), True),
      StructField("first_name", StringType(), False),
      StructField("middle_initial", StringType(), True),
      StructField("last_name", StringType(), False),
      StructField("suffix", StringType(), True),
      StructField("date_of_birth", TimestampType(), False),
      StructField("street", StringType(), False),
      StructField("city", StringType(), False),
      StructField("state_province", StringType(), False),
      StructField("country", StringType(), False),
      StructField("postal_code", StringType(), False),
      StructField("email", StringType(), True),
      StructField("phone", StringType(), True),
      StructField("tax_id", StringType(), False),
      StructField("tax_id_type", StringType(), False),
      StructField("personal_id", StringType(), False),
      StructField("personal_id_type", StringType(), False),
      StructField("personal_id_registrar", StringType(), False),
      StructField("created", TimestampType(), False),
      StructField("last_update", TimestampType(), False),
    ]
  )
  
  party_schema = StructType(
    [
      StructField("party_uuid", StringType(), False),
      StructField("account_uuid", StringType(), False),
      StructField("customer_uuid", StringType(), False),
      StructField("description", StringType(), True),
      StructField("status", StringType(), True),
      StructField("created", TimestampType(), False),
      StructField("last_update", TimestampType(), True),
    ]
  )
  
  product_schema = StructType(
    [
      StructField("product_uuid", StringType(), False),
      StructField("description", StringType(), False),
      StructField("category", StringType(), True),
      StructField("apr", FloatType(), True),
      StructField("created", TimestampType(), False),
      StructField("last_update", TimestampType(), False),
    ]
  )
  
  transaction_schema = StructType(
    [
      StructField("transaction_uuid", StringType(), False),
      StructField("account_uuid", StringType(), False),
      StructField("debit_credit", StringType(), False),
      StructField("amount", DoubleType(), False),
      StructField("tran_code", StringType(), True),
      StructField("date", TimestampType(), False),
      StructField("merchant", StringType(), True),
      StructField("category", StringType(), True),
      StructField("status", StringType(), False),
    ]
  )