# Databricks notebook source
# MAGIC %run ../backbone

# COMMAND ----------

# MAGIC %run ../test_utils

# COMMAND ----------

notebook_info = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
print(json.dumps(notebook_info, indent=4))

org_id = notebook_info["tags"]["orgId"]
notebook_name = notebook_info["extraContext"]["notebook_path"].split("/")[-1]
try:
  cluster = notebook_info["tags"]["browserHostName"]
except:
  cluster = ""

# COMMAND ----------

"""Load arguments form the driver."""
try:
  test = False
  job_id = getArgument("job_id")
  
  src_db = getArgument("src_db")
  target_db = getArgument("target_db")
  help_db = getArgument("help_db")
  report_db = getArgument("report_db")
  report_table = getArgument("report_table")
  
  max_threads = int(getArgument("max_threads"))
  test_case_parameters = eval(getArgument("test_case_parameters"))
  
  
except Exception as e:  # Exception case for testing notebooks using interactive mode
  print(f"{str(type(e))}: {e}")
  
  test = True
  job_id = -1
  
  src_db = Backbone.src_db
  target_db = Backbone.target_db
  help_db = Backbone.help_db
  report_db = Backbone.report_db
  report_table = Backbone.report_table
  
  max_threads = 4
  
  test_case_parameters = []
  test_case_query = f"""
  SELECT *
  FROM {help_db}.test_case
  WHERE test_function = "{notebook_name}"
  """ 
  print(test_case_query)
  test_case_df = spark.sql(test_case_query)
  for row in test_case_df.collect():
    test_case = {
      "id": row["id"],
      "description": row["description"],
      "src_table": row["src_table"],
      "src_column": row["src_column"],
      "target_table": row["target_table"],
      "target_column": row["target_column"],
      "condition": row["condition"],
    }
    test_case_parameters.append(test_case)

job_url = f"https://{cluster}/?o={org_id}#job/{job_id}/run/1"
print(test_case_parameters)

# COMMAND ----------

def query_data(test_case_id: int, root_key: str, src_db: str, src_table: str, src_column: str, target_db: str, target_table: str, target_column: str, condition: str) -> DataFrame or None:
  """Query column data."""
  assert type(test_case_id) is int
  assert type(root_key) is str
  assert type(src_db) is str
  assert type(src_table) is str
  assert type(src_column) is str
  assert type(target_db) is str
  assert type(target_table) is str
  assert type(target_column) is str
  
  query = f"""
    SELECT target.{root_key} AS root_key,
           {condition} AS source_data_value,
           CAST(target.{target_column} AS DECIMAL(16,2)) AS target_data_value
    FROM {target_db}.{target_table} AS target"""
  
  if test:
    print(query)
  
  try:
    df = spark.sql(query)
    return df,query
  except Exception as e:
    print(f"{test_case_id} - {str(type(e))}: {e}")
    return None

# COMMAND ----------

def match_values(source: [str, int, None] =None, target: [str, int, None] =None) -> str:
  """Compare columns and return a pass/fail result.""" 
  if target is None:
    return "fail"
  else:
    # Verify types and values are the same
    return "pass" if len(str(target).split(".")[1]) <= int(source) else "fail"

match_values_udf = udf(match_values, returnType=StringType())

# COMMAND ----------

def process_result(
  df: DataFrame,
  test_case_id: int,
  root_key: str,
  src_db: str,
  src_table: str,
  src_column: str,
  target_db: str,
  target_table: str,
  target_column: str,
  condition: str,
  notebook_udf: udf
) -> DataFrame:
  """Process the test results in a "fail fast" technique.
     Query a sample of the dataset for failures. If the algorithm
     does not find failures in the sample, re-test against the
     entire data population.
  """
  fail_count = df.filter('result=="fail"').count()
  
  # Determine if a re-test with all records is required
  if fail_count == 0:  # All pass
    return df.filter('result="pass"').limit(1)
  else:  # Return failures from sample without limit
    return df.filter('result="fail"').limit(1)
  
  df = df.withColumn("result", notebook_udf("source_data_value", "target_data_value"))


# COMMAND ----------

def process_row(row,df=None):
  """Process a row within a test case DataFrame."""
  start = datetime.now()
  
  root_key = root_key_columns(target_db, row["target_table"])  # Get the root key
  test_data,query_string = query_data(
    row["id"],
    root_key,
    src_db,
    row["src_table"],
    row["src_column"],
    target_db,
    row["target_table"],
    row["target_column"],
    row["condition"]
  )  # Get test data
  test_data = test_data.withColumn("result", match_values_udf("source_data_value", "target_data_value"))  # Add result column
  
  # Process results and determine if a full test against the population is required
  test_data = process_result(
    test_data,
    row["id"],
    root_key,
    src_db,
    row["src_table"],
    row["src_column"],
    target_db,
    row["target_table"],
    row["target_column"],
    row["condition"],
    match_values_udf
  )
  
  test_data = test_data.select(
    lit(job_id).alias("job_id"),
    lit(row["id"]).alias("test_case_id"),
    lit(row["description"]).alias("test_description"),
    lit(row["src_table"]).alias("source_table"),
    lit(row["src_column"]).alias("source_column"),
    lit(row["target_table"]).alias("target_table"),
    lit(row["target_column"]).alias("target_column"),
    col("root_key"),
    col("source_data_value").cast(StringType()),
    col("target_data_value").cast(StringType()),
    col("result"),
    lit(f"url: {job_url}").alias("comments"),
    lit(query_string).alias("sql_query")
  )
  # Convert test data to report schema
  return test_data

# COMMAND ----------

if test:
  print(test_case_parameters[0])
  df = process_row(test_case_parameters[0])
  display(df)

# COMMAND ----------

results = []

with ThreadPoolExecutor(max_threads) as executor:
  """Use multithreading to execute multiple test cases at one time.
     The algorithm below uses Row objects instead of DataFrames to reduce compute overhead and to simplify DAGs.
  """
  for result in executor.map(execute, test_case_parameters):
    result_row = result.first()  # Get the first result back as there should only be one row returned per test case
    results.append(result_row)

# COMMAND ----------

"""Convert list of Row objects to a DataFrame"""
result_rdd = sc.parallelize(results)
report_df = spark.createDataFrame(data=result_rdd, schema=Backbone.report_schema)
if test:
  report_df.display()

# COMMAND ----------

"""Write results to the result reporting table."""
report_df.write.format("delta").mode("append").saveAsTable(f"{report_db}.{report_table}")
print(f"Test report for {report_df.count()} data points written to {report_db}.{report_table} with job ID: {job_id}")

# COMMAND ----------

dbutils.notebook.exit(job_id)

# COMMAND ----------

# MAGIC %sql SELECT target.product_uuid AS root_key, 2 AS source_data_value, target.apr AS target_data_value FROM demo_target.product AS target --where id = '245'