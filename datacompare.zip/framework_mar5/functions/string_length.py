# Databricks notebook source
# MAGIC %run ../backbone

# COMMAND ----------

# MAGIC %run ../test_utils

# COMMAND ----------

notebook_info = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
print(json.dumps(notebook_info, indent=4))

org_id = notebook_info["tags"]["orgId"]
notebook_name = notebook_info["extraContext"]["notebook_path"].split("/")[-1]
try:
  cluster = notebook_info["tags"]["browserHostName"]
except:
  cluster = ""

# COMMAND ----------

"""Load arguments form the driver."""
try:
  test = False
  job_id = getArgument("job_id")
  
  src_db = getArgument("src_db")
  target_db = getArgument("target_db")
  help_db = getArgument("help_db")
  report_db = getArgument("report_db")
  report_table = getArgument("report_table")
  
  max_threads = int(getArgument("max_threads"))
  test_cases = eval(getArgument("test_case_parameters"))
  
  try:
    max_fail = int(getArgument("max_fail"))
  except:
    max_fail = None
  
except Exception as e:  # Exception case for testing notebooks using interactive mode
  print(f"{str(type(e))}: {e}")
  
  test = True
  job_id = -1
  
  src_db = Backbone.src_db
  target_db = Backbone.target_db
  help_db = Backbone.help_db
  report_db = Backbone.report_db
  report_table = Backbone.report_table
  
  max_threads = 4
  max_fail = 1
  
  test_cases = []
  test_case_query = f"""
  SELECT *
  FROM {help_db}.test_case
  WHERE test_function = "{notebook_name}"
  """
  print(test_case_query)
  test_case_df = spark.sql(test_case_query)
  for row in test_case_df.collect():
    test_case = {
      "id": row["id"],
      "description": row["description"],
      "src_table": row["src_table"],
      "src_column": row["src_column"],
      "target_table": row["target_table"],
      "target_column": row["target_column"],
      "condition": row["condition"],
    }
    test_cases.append(test_case)

job_url = f"https://{cluster}/?o={org_id}#job/{job_id}/run/1"
limit = get_limit(max_fail)
print(test_cases)

# COMMAND ----------

def query_data(test_case_id: int, root_key: str, db: str, table: str, column: str, condition: str, limit: int =None) -> DataFrame or None:
  """Query column data."""
  assert type(test_case_id) is int
  assert type(root_key) is str
  assert type(db) is str
  assert type(table) is str
  assert type(column) is str
  assert type(limit) is int or limit is None
  
  query = f"""
  SELECT {root_key} AS root_key,
         CAST(LENGTH({column}) AS INT) AS source_data_value,
         CAST({condition} AS INT) AS target_data_value
  FROM {db}.{table}"""
  
  if limit:
    query = f"{query}\n  LIMIT {limit}"
  
  if test:
    print(query)
  
  try:
    df = spark.sql(query)
    return df
  except Exception as e:
    print(f"{test_case_id} - {str(type(e))}: {e}")
    return None

# COMMAND ----------

def query_data_string(test_case_id: int, root_key: str, db: str, table: str, column: str, condition: str, limit: int =None) -> DataFrame or None:
  """Query column data."""
  assert type(test_case_id) is int
  assert type(root_key) is str
  assert type(db) is str
  assert type(table) is str
  assert type(column) is str
  assert type(limit) is int or limit is None
  
  query = f"""
  SELECT {root_key} AS root_key,
         CAST(LENGTH({column}) AS INT) AS source_data_value,
         CAST({condition} AS INT) AS target_data_value
  FROM {db}.{table}"""
  if limit:
    query = f"{query}\n  LIMIT {limit}"
 
  return query

# COMMAND ----------

def match_values(source: [str, int, None] =None, target: [str, int, None] =None) -> str:
  """Compare columns and return a pass/fail result."""
  if source is None and target is None:
    return "pass"
  elif source is None:
    return "fail"
  elif target is None:
    return "fail"
  else:
    assert type(source) in [str, int]
    assert type(target) in [str, int]
    if type(source) is str:
      assert source.isdigit()
    if type(target) is str:
      assert target.isdigit()

    # For length checks, cast data as an int
    return "pass" if int(source) <= int(target) else "fail"

match_values_udf = udf(match_values, returnType=StringType())

# COMMAND ----------

def process_result(df: DataFrame, test_case_id: int, root_key: str, db: str, table: str, column: str, condition: str, notebook_udf: udf, limit: int =None, max_fail: int =None) -> DataFrame:
  """Process the test results in a "fail fast" technique.
     Query a sample of the dataset for failures. If the algorithm
     does not find failures in the sample, re-test against the
     entire data population.
  """
  fail_count = df.filter('result=="fail"').count()
  
  # Determine if a re-test with all records is required
  if max_fail is None:
    if fail_count == 0:  # All pass
      return df.filter('result="pass"').limit(1)
    else:  # Return failures from sample without limit
      return df.filter('result="fail"')
  elif fail_count >= max_fail:  # Failure found in sample set and report the maximum samples
    return df.filter('result="fail"').limit(max_fail)
  else:  # Re-test the entire population
    df = query_data(test_case_id, root_key, db, table, column, condition)
    df = df.withColumn("result", notebook_udf("source_data_value", "target_data_value"))
    
    if df.filter('result="pass"').count() == df.count():
      return df.filter('result="pass"').limit(1)  # All pass
    else:
      return df.filter('result="fail"').limit(max_fail)  # Failure found in population and report the maximum samples

# COMMAND ----------

def process_row(row: Row) -> Row:
  """Process a row within a test case DataFrame."""
  start = datetime.now()
  
  root_key = root_key_columns(target_db, row["target_table"])  # Get the root key
  test_data = query_data(row["id"], root_key, target_db, row["target_table"], row["target_column"], row["condition"], limit=limit)  # Get test data
  query_string = query_data_string(row["id"], root_key, target_db, row["target_table"], row["target_column"], row["condition"], limit=limit)
  test_data = test_data.withColumn("result", match_values_udf("source_data_value", "target_data_value"))  # Add result column
  
  # Process results and determine if a full test against the population is required
  test_data = process_result(test_data, row["id"], root_key, target_db, row["target_table"], row["target_column"], row["condition"], match_values_udf, limit=limit, max_fail=max_fail)
  
  test_data = test_data.select(
    lit(job_id).alias("job_id"),
    lit(row["id"]).alias("test_case_id"),
    lit(row["description"]).alias("test_description"),
    lit(row["src_table"]).alias("source_table"),
    lit(row["src_column"]).alias("source_column"),
    lit(row["target_table"]).alias("target_table"),
    lit(row["target_column"]).alias("target_column"),
    col("root_key"),
    col("source_data_value").cast(StringType()),
    col("target_data_value").cast(StringType()),
    col("result"),
    lit(f"url: {job_url}").alias("comments"),
    lit(query_string).alias("sql_query")
  )
  
  # Convert test data to report schema
  return test_data

# COMMAND ----------

if test:
  print(test_case_parameters[0])
  df = process_row(test_case_parameters[0])
  display(df)

# COMMAND ----------

results = []

with ThreadPoolExecutor(max_threads) as executor:
  """Use multithreading to execute multiple test cases at one time.
     The algorithm below uses Row objects instead of DataFrames to reduce compute overhead and to simplify DAGs.
  """
  for result in executor.map(execute, test_cases):
    result_row = result.first()  # Get the first result back as there should only be one row returned per test case
    results.append(result_row)

# COMMAND ----------

"""Convert list of Row objects to a DataFrame"""
result_rdd = sc.parallelize(results)
report_df = spark.createDataFrame(data=result_rdd, schema=Backbone.report_schema)
if test:
  report_df.display()

# COMMAND ----------

"""Write results to the result reporting table."""
report_df.write.format("delta").mode("append").saveAsTable(f"{report_db}.{report_table}")
print(f"Test report for {report_df.count()} data points written to {report_db}.{report_table} with job ID: {job_id}")

# COMMAND ----------

dbutils.notebook.exit(job_id)