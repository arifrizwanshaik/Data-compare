# Databricks notebook source
# MAGIC %run ../backbone

# COMMAND ----------

# MAGIC %run ../test_utils

# COMMAND ----------

def next_test_id(base = 1) -> int:
  """Get the next test case ID."""
  df = spark.sql(f"""SELECT MAX(id) AS id FROM {Backbone.help_db}.test_case""")
  try:
    return int(df.select("id").first()[0])+1
  except TypeError as e:
    return base
def add_test_case(test_function, src_table, src_column, target_table, target_column, db_name, value, condition = 'null'):
  id = next_test_id()
  description = f'Validate {test_function} for {db_name}.{target_table}.{target_column}'
  test_case = {'id': id,
               'description': description,
               'src_table': src_table,
               'src_column': src_column,
               'target_table': target_table,
               'target_column': target_column,
               'test_function': test_function,
               'condition': condition
              }
  query = f"""
    INSERT INTO {Backbone.help_db}.test_case VALUES
    (
    {id}, "{description}", "{src_table}", "{src_column}", "{target_table}", "{target_column}", "{test_function}", {condition}, "{value}"
    )
  """
  #spark.sql(query)
  #df = spark.createDataFrame(data=[test_case], schema=Backbone.test_case_schema)
  #df.display()
  #df.write.format("delta").mode("append").saveAsTable(f"{Backbone.help_db}.test_case")
add_test_case('valid_values_target', 'null', 'null', 'product', 'category', 'demo_target', "'credit card','LOC','loan','savings','DDA'")

# COMMAND ----------

notebook_info = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
print(json.dumps(notebook_info, indent=4))

org_id = notebook_info["tags"]["orgId"]
notebook_name = notebook_info["extraContext"]["notebook_path"].split("/")[-1]
try:
  cluster = notebook_info["tags"]["browserHostName"]
except:
  cluster = ""

# COMMAND ----------

try:
  test = False
  job_id = getArgument("job_id")
  
  src_db = getArgument("src_db")
  target_db = getArgument("target_db")
  help_db = getArgument("help_db")
  report_db = getArgument("report_db")
  report_table = getArgument("report_table")
  
  max_threads = int(getArgument("max_threads"))
  test_cases = eval(getArgument("test_case_parameters"))
  
  try:
    max_fail = int(getArgument("max_fail"))
  except:
    max_fail = None
  
except Exception as e:  # Exception case for testing notebooks using interactive mode
  print(f"{str(type(e))}: {e}")
  test = True
  job_id = -1
  src_db = Backbone.src_db
  target_db = Backbone.target_db
  help_db = Backbone.help_db
  report_db = Backbone.report_db
  report_table = Backbone.report_table
  
  max_threads = 4
  max_fail = 1
  test_cases = []
  test_case_query = f"""
  SELECT *
  FROM {help_db}.test_case
  WHERE test_function = "{notebook_name}"
  """
  test_case_df = spark.sql(test_case_query)
  for row in test_case_df.collect():
    test_case = {
      "id": row["id"],
      "description": row["description"],
      "src_table": row["src_table"],
      "src_column": row["src_column"],
      "target_table": row["target_table"],
      "target_column": row["target_column"],
      "condition": row["condition"],
      "value": row["value"]
    }
    test_cases.append(test_case)
  ctc = {
    "id": '-1',
    "description": 'test tc',
    "src_table": 'account',
    "src_column": 'balance',
    "target_table": 'account',
    "target_column": 'balance',
    "condition": 'null'
  }
  #test_cases.append(ctc)
print('done')
job_url = f"https://{cluster}/?o={org_id}#job/{job_id}/run/1"
limit = get_limit(max_fail)


# COMMAND ----------

def query_data(test_case, root_key, db, table, column, values):
  query = """
  SELECT {root_key} AS root_key,
  {column} AS target_data,
  (CASE WHEN {column} IN ({values}) THEN 'pass' ELSE 'fail' END) AS result
  FROM {db}.{table}
  """.format(root_key=root_key, column=column, db=db, table=table, values=values)
  try:
    df = spark.sql(query)
    return df, query
  except Exception as e:
    print(f"{test_case_id} - {str(type(e))}: {e}")
    return None
  

# COMMAND ----------

def process_row(row):
  root_key = root_key_columns(target_db, row["target_table"]) 
  results, query_string = query_data(row["id"], root_key, target_db, row["target_table"], row["target_column"], row["value"])
  fails = results.filter('result="fail"').count()
  if fails == 0:
    df = results.filter('result="pass"').limit(1)
  else:  # Return failures from sample without limit
    df = results.filter('result="fail"').limit(1)
  
  test_data = df.select(
    lit(job_id).alias("job_id"),
    lit(row["id"]).alias("test_case_id"),
    lit(row["description"]).alias("test_description"),
    lit(row["src_table"]).alias("source_table"),
    lit(row["src_column"]).alias("source_column"),
    lit(row["target_table"]).alias("target_table"),
    lit(row["target_column"]).alias("target_column"),
    col("root_key"),
    lit("null").alias("source_data_value"),
    col("target_data").cast(StringType()).alias("target_data_value"),
    col("result"),
    lit(f"url: {job_url}").alias("comments"),
    lit(query_string).alias("sql_query")
  )
  # Convert test data to report schema
  return test_data

# COMMAND ----------

results = []

with ThreadPoolExecutor(max_threads) as executor:
  """Use multithreading to execute multiple test cases at one time.
     The algorithm below uses Row objects instead of DataFrames to reduce compute overhead and to simplify DAGs.
  """
  for result in executor.map(execute, test_cases):
    result_row = result.first()  # Get the first result back as there should only be one row returned per test case
    results.append(result_row)
    result.display()

# COMMAND ----------

result_rdd = sc.parallelize(results)
report_df = spark.createDataFrame(data=result_rdd, schema=Backbone.report_schema)
if test:
  report_df.display()

# COMMAND ----------

"""Write results to the result reporting table."""
if not test:
  report_df.write.format("delta").mode("append").saveAsTable(f"{report_db}.{report_table}")
  print(f"Test report for {report_df.count()} data points written to {report_db}.{report_table} with job ID: {job_id}")

# COMMAND ----------

dbutils.notebook.exit(job_id)