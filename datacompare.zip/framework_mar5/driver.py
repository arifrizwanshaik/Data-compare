# Databricks notebook source
# MAGIC %run ./backbone

# COMMAND ----------

# MAGIC %run ./test_utils

# COMMAND ----------

import json
from datetime import datetime

# COMMAND ----------

# Gather notebook information in the context of the current run
notebook_info = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())

try:
  job_id = notebook_info["tags"]["jobId"]
  orgId = notebook_info["tags"]["orgId"]
except:
  job_id = -1

print(job_id)
print(json.dumps(notebook_info, indent=4))

# COMMAND ----------

# Timeout
try:
  TIMEOUT_IN_SECONDS = int(getArgument('timeout'))
except:
  TIMEOUT_IN_SECONDS = 8*60*60  # 8 hours
# Thread settings
try:
  max_threads = getArgument('max_threads')
except:
  max_threads = 4

# Notebook relative path
ROOT = './'

# Load DB names
try:
  help_db = getArgument('help_db')
except:
  help_db = Backbone.help_db

try:
  report_db = getArgument('report_db')
except:
  report_db = Backbone.report_db
try:
  src_db = getArgument('src_db')
except:
  src_db = Backbone.src_db
try:
  target_db = getArgument('target_db')
except:
  target_db = Backbone.target_db

# Load report table
try:
  report_table = getArgument("report_table")
except:
  report_table = Backbone.report_table

# Load test cases passed from job controller
try:
  test_cases = getArgument('test_cases')
except Exception as e:
  print(e)

job_timestamp = datetime.now()

# COMMAND ----------

# Stage job by fetching test case details
test_case_query = f"""
SELECT *
FROM {help_db}.test_case
WHERE id IN ({test_cases})
"""
print(test_case_query)
tests = spark.sql(test_case_query)
tests.display()

# COMMAND ----------

# Set test function notebook initialization arguments
notebook_args = {
  "job_id": job_id,
  "help_db": help_db,
  "src_db": src_db,
  "target_db": target_db,
  "report_db": report_db,
  "report_table": report_table,
  "test_cases": test_cases,
  "max_threads": max_threads
}
print(notebook_args)

# COMMAND ----------

"""Group test cases by function name."""
function_names = [function[0] for function in tests.select("test_function").distinct().collect()]
print(f"{len(function_names)} function names found")

function_dfs = [tests.filter(col("test_function") == fx) for fx in function_names]
print(f"{len(function_dfs)} function test groups found")

# COMMAND ----------

def test_case_args(row):
  """Create the arguments to pass to the notebook for a given test case."""
  args = dict()
  args["id"] = row["id"]
  args["description"] = row["description"]
  args["src_table"] = row["src_table"]
  args["src_column"] = row["src_column"]
  args["target_table"] = row["target_table"]
  args["target_column"] = row["target_column"]
  args["condition"] = row["condition"]
  args["value"] = row["value"]
  
  for key, value in args.items():
    if value is None:
      args[key] = ""
  
  return args

# COMMAND ----------

def process_batch(batch):
  """ Execute a test function with a batch of test cases."""
  args = notebook_args.copy()
  test_case_parameters = []
  
  for row in batch.collect():
    test_case_parameters.append(test_case_args(row))
  
  args["test_case_parameters"] = str(test_case_parameters)
  
  notebook = batch.select(col("test_function")).first()[0]
  notebook_path = f"functions/{notebook}"
  
  try:
    test_case_job_id = dbutils.notebook.run(notebook_path, TIMEOUT_IN_SECONDS, args)
  except Exception as e:
    raise e

# COMMAND ----------

"""Execute each test function (and associated group of test cases) one at a time (with multithreading within the notebooks)."""
for test_batch_df in function_dfs:
  try:
    test_batch_df.display()
    process_batch(test_batch_df)
  except Exception as e:
    print(f"{str(type(e))}: {e}")

# COMMAND ----------

dbutils.notebook.exit(job_id)