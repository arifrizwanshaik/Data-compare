# Databricks notebook source
# MAGIC %run ./backbone

# COMMAND ----------

query = f"""
SELECT *
FROM {Backbone.help_db}.{Backbone.report_table}
"""
spark.sql(query).display()

# COMMAND ----------

# TODO: Prefix table names with src_ and tgt_

# COMMAND ----------

query = f"""
SELECT *
FROM {Backbone.help_db}.test_case
"""
spark.sql(query).display()