# Databricks notebook source
# MAGIC %run ../backbone

# COMMAND ----------

"""Execute test cases based on job parameters and print results along with an exception report."""
dbutils.widgets.text("src_db", Backbone.src_db)  # Source database
dbutils.widgets.text("target_db", Backbone.target_db)  # Source database
dbutils.widgets.text("help_db", Backbone.help_db)  # Helper database
dbutils.widgets.text("report_db", Backbone.report_db)  # Report database
dbutils.widgets.text("report_table", Backbone.report_table)  # Table for writing results
dbutils.widgets.text("target_tables", "")  # Test only specific target tables (e.g., "transaction")
dbutils.widgets.text("include_functions", "")  # Specifically include only specific functions (e.g., "length_check,direct_mapping")
dbutils.widgets.text("exclude_functions", "")  # Exclude certain functions (e.g., "length_check,direct_mapping")
dbutils.widgets.text("include_test_cases", "")  # Specifically include only specific test cases (e.g., "1234,1235")
dbutils.widgets.text("exclude_test_cases", "")  # Exclude certain test cases (e.g., "4567,789")
dbutils.widgets.text("test_case_limit", "")  # Maximum number of test cases to execute (e.g., "25"); default of None indicates no limit
dbutils.widgets.text("max_threads", "4")  # Maximum number of threads for multithreading; refer to cluster compute CPUs; maximum is # of CPUs - 4

# COMMAND ----------

"""Load db context from widgets."""
src_db = dbutils.widgets.get("src_db").lower()
target_db = dbutils.widgets.get("target_db").lower()
help_db = dbutils.widgets.get("help_db").lower()
report_db = dbutils.widgets.get("report_db").lower()
report_table = dbutils.widgets.get("report_table").lower()

# COMMAND ----------

"""Print parameters for future use."""
widget_params = {
  "src_db": dbutils.widgets.get("src_db"),
  "target_db": dbutils.widgets.get("target_db"),
  "help_db": dbutils.widgets.get("help_db"),
  "report_db": dbutils.widgets.get("report_db"),
  "report_table": dbutils.widgets.get("report_table"),
  "target_tables": dbutils.widgets.get("target_tables"),
  "include_functions": dbutils.widgets.get("include_functions"),
  "exclude_functions": dbutils.widgets.get("exclude_functions"),
  "include_test_cases": dbutils.widgets.get("include_test_cases"),
  "exclude_test_cases": dbutils.widgets.get("exclude_test_cases"),
  "test_case_limit": dbutils.widgets.get("test_case_limit"),
  "max_threads": dbutils.widgets.get("max_threads"),
}

widget_json = json.dumps(widget_params, indent=4)
print(widget_json)

# COMMAND ----------

def clean(param_str: str) -> str:
  """Remove special characters from list items."""
  assert type(param_str) == str 
  param_str = param_str.lower().strip()
  param_str = param_str.replace('"', "").replace("'","")
  return f'"{param_str}"'
  

# COMMAND ----------

"""Load inclusions and exclusions."""
target_tables =[clean(x) for x in dbutils.widgets.get("target_tables").split(",")] if len(dbutils.widgets.get("target_tables")) > 0 else None
include_functions =[clean(x) for x in dbutils.widgets.get("include_functions").split(",")] if len(dbutils.widgets.get("include_functions")) > 0 else None
exclude_functions =[clean(x) for x in dbutils.widgets.get("exclude_functions").split(",")] if len(dbutils.widgets.get("exclude_functions")) > 0 else None
include_test_cases = [x.strip() for x in dbutils.widgets.get("include_test_cases").split(",")] if len(dbutils.widgets.get("include_test_cases")) > 0 else None
exclude_test_cases =[x.strip() for x in dbutils.widgets.get("exclude_test_cases").split(",")] if len(dbutils.widgets.get("exclude_test_cases")) > 0 else None

# COMMAND ----------

"""Load job meta settings."""
test_case_limit = int(dbutils.widgets.get("test_case_limit")) if len(dbutils.widgets.get("test_case_limit")) > 0 else None
max_threads = int(dbutils.widgets.get("max_threads")) if len(dbutils.widgets.get("max_threads")) > 0 else 4

# COMMAND ----------

"""Collect test cases based on parameters."""
test_case_query = f"""
SELECT id
FROM {help_db}.test_case
"""

where_clause = "WHERE"
conditions = []
if target_tables:
  conditions.append(f"target_table IN ({','.join(target_tables)})")

if include_functions:
  conditions.append(f"test_function IN ({','.join(include_functions)})")

if exclude_functions:
  conditions.append(f"test_function NOT IN ({','.join(exclude_functions)})")

if include_test_cases:
  conditions.append(f"id IN ({','.join(include_test_cases)})")

if exclude_test_cases:
  conditions.append(f"id NOT IN ({','.join(exclude_test_cases)})")

if len(conditions) > 0:
  where_clause = f"{where_clause} {' AND '.join(conditions)}"

if where_clause != "WHERE":
  test_case_query = f"{test_case_query}{where_clause}"

if test_case_limit:
  test_case_query = f"{test_case_query}\nLIMIT {test_case_limit}"

print(test_case_query)
test_cases = spark.sql(test_case_query)

# COMMAND ----------

"""Verify at least one test case came back for the query."""
tc_count = test_cases.count()
print(f"{tc_count} test cases in batch")
assert tc_count > 0

# COMMAND ----------

"""Display test case details."""
display(test_cases)

# COMMAND ----------

"""Create test case id list for JSON notebook parameter."""
test_case_ids = ",".join([str(tc.id) for tc in test_cases.collect()])
print(f"Test cases to be passed to driver: \"{test_case_ids}\"")

# COMMAND ----------

"""Prep driver parameters."""
TIMEOUT_IN_SECONDS = 8*60*60  # 8 hours
ROOT = "../"
driver = f"{ROOT}driver"
driver_params = {
  "src_db": src_db,
  "target_db": target_db,
  "help_db": help_db,
  "report_db": report_db,
  "report_table": report_table,
  "test_cases": test_case_ids,
  "max_threads": max_threads,
  "timeout": TIMEOUT_IN_SECONDS,
}

print(json.dumps(driver_params, indent=4))

# COMMAND ----------

"""Execute driver."""
job_id = dbutils.notebook.run(driver, TIMEOUT_IN_SECONDS, driver_params)

# COMMAND ----------

df = spark.sql(f"SELECT * FROM {report_db}.{report_table} WHERE job_id = {job_id}")
df.display()

# COMMAND ----------

# Exceptions
df.filter(df.result != "pass").display()